<?php 
header("location:edit_user.php");
?>