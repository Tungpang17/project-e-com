Interfaces
----------
This directory contains boilerpalte code to show you how to open a print connector
to printers which are connected in different ways.

To get a list of supported interfaces and operating systems, see the main README.md file for the project.

If you have a printer interface with no example, and you want to help put one together, then please lodge a request on the bug tracker: https://github.com/mike42/escpos-php/issues
