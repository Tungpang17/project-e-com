Specific examples
-----------------

These examples are designed for specific combinations of language,
printer and interface.

They are documented here because the general examples all set up the printer in a similar way.
