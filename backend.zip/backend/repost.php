<?php
include("head.php");
?>
<br>
<br>
<br>


<div class="container">
	<center>
	<h3>รายงาน</h3> <br>

<div class="row">
  <div>


<a class="btn btn-secondary btn-lg btn-block" href="repost_member.php" role="button">รายงานข้อมูลสมาชิก</a>
<!-- <a class="btn btn-secondary btn-lg btn-block" href="repost_com.php" role="button">รายงานข้อมูลสถานประกอบการ</a> -->
<a class="btn btn-secondary btn-lg btn-block" href="repost_admin_user.php" role="button">รายงานสิทธิ์การเข้าใช้</a>

<!-- <a class="btn btn-secondary btn-lg btn-block" href="repost_user.php" role="button">รายงานข้อมูลพนักงาน</a> -->

<a class="btn btn-secondary btn-lg btn-block" href="repost_tailorss.php" role="button">รายงานข้อมูลสมาชิกกลุ่มทอผ้า</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_product.php" role="button">รายงานข้อมูลสินค้า</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_tailor-records.php" role="button">รายงานข้อมูลการทอผ้าตามชื่อสมาชิก (วัน/เดือน/ปี)</a>




<!-- <a class="btn btn-secondary btn-lg btn-block" href="repost_pomotion.php" role="button">รายงานข้อมูลโปรโมชั่น (ตามช่วงเวลาที่กำหนด)</a> -->
<!-- <a class="btn btn-danger btn-lg btn-block" href="repost_stcok.php" role="button">รายงานสินค้าเข้าสต็อก</a> -->

<a class="btn btn-secondary btn-lg btn-block" href="repost_order.php" role="button">รายงานข้อมูลการสั่งซื้อสินค้า ตามเลขใบสั่งซื้อ/ชื่อลูกค้า(วัน/เดือน/ปี)</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_payment.php" role="button">รายงานข้อมูลการชำระเงิน ตามเลขใบสั่งซื้อ/ชื่อลูกค้า(วัน/เดือน/ปี)</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_transport.php" role="button">รายงานข้อมูลการจัดส่งสินค้า ตามชื่อลูกค้า/ตามวันที่จัดส่ง (วัน/เดือน/ปี)</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_popular.php" role="button">รายงานข้อมูลสถิติการขายสินค้า5อันดับยอดนิยม</a>
<a class="btn btn-secondary btn-lg btn-block" href="repost_tailor_record.php" role="button">รายงานข้อมูลสถิติการทอผ้าของสมาชิกกลุ่มทอผ้า</a>
</div>
</div><br>
<?php
include("foot.php");
?>